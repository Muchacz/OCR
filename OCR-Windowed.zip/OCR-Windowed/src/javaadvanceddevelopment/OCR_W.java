/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaadvanceddevelopment;

import java.awt.Color;
import java.awt.Image;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.TransferHandler;
import javax.swing.border.LineBorder;

/**
 *
 * @author Ivo Hanuš
 */
public class OCR_W extends javax.swing.JFrame {

    BufferedImage image;

    /**
     * Metoda připravující vlastnosti komponentě v okně
     */
    public OCR_W() {
        super("Optical Character Reader");      //Nastaví titulek okna
        initComponents();       //inicializuje části okna a jejich vlastnosti

        //Na začátku je vidět jen okno na přetažení obrázku
        instructionLabel.setVisible(false);
        colonLabel.setVisible(false);
        recognizedLetter.setVisible(false);
        jRadioButton1.setVisible(false);
        jRadioButton2.setVisible(false);
        correctingTextField.setVisible(false);
        saveButton.setVisible(false);

        handleComponents();
    }

    /**
     * Každé komponentě definuje reakční metody
     */
    private void handleComponents() {
        //Reakce na přetažení obrázku
        pictureLabel.setTransferHandler(new TransferHandler() {
            @Override
            public boolean canImport(JComponent comp, DataFlavor[] transferFlavors) {       //při volání metody canImport se musí vrátit true
                return true;
            }

            /**
             * @param comp pole na přetažení obrázku
             * @param t přetažený obrázek
             * @return
             */
            @Override
            public boolean importData(JComponent comp, Transferable t) {        //metoda spuštěná, když se do labelu přetáhl soubor
                List<File> files = null;        //použit List namísto Set, aby se z něj dal později snáze načíst jediný obrýzek
                try {
                    files = (List<File>) t.getTransferData(DataFlavor.javaFileListFlavor);
                } catch (UnsupportedFlavorException | IOException ex) {
                    Logger.getLogger(OCR_W.class.getName()).log(Level.SEVERE, null, ex);
                }

                if (files != null) {        //Zatím bez exceptiony
                    if (files.size() != 1) {
                        System.out.println("Nahraj pouze jeden obrázek!");      //Jak pošéfit tohle, aby se hláška zobrazila v okně?

                    } else {
                        File imageFile = files.get(0);      //kvůli tomuto je snazší použít list namísto set

                        //Zmenší pictureLabel, aby se do okna později vešly fileIndex další komponenty
                        if (!saveButton.isVisible()) {
                            pictureLabel.setSize(pictureLabel.getWidth(), pictureLabel.getHeight() - 30 - 11 - 47 - 19 + 2);
                            //30 je výška instructionLabelu, 11 výška layout gapu pod ním, 47 výška oněch dalších komponentů (nelze přes Button.getHeight() apod.), 19 je výška spodního layout gapu, 2 pixely se ztrácí při zobrazení oněch dalších komponentů
                        }

                        //Škálování - obrázek v okně vyžaduje jiné rozměry než má ten surový importovaný
                        Image imageOfIcon = new ImageIcon(imageFile.getPath()).getImage();
                        imageOfIcon = imageOfIcon.getScaledInstance(
                                pictureLabel.getWidth() - 2 * ((LineBorder) pictureLabel.getBorder()).getThickness(),
                                pictureLabel.getHeight() - 2 * ((LineBorder) pictureLabel.getBorder()).getThickness(),
                                Image.SCALE_SMOOTH);      // - 2 × šířka borders, aby se to mezi borders vešlo (při znovunahrávání obrázku)
                        ImageIcon icon = new ImageIcon(imageOfIcon);

                        //V poli se zobrazí importovaný obrázek
                        pictureLabel.setText("");
                        pictureLabel.setIcon(icon);

                        //Uložení obrázku do proměnné image
                        try {
                            image = ImageIO.read(imageFile);
                        } catch (Exception e) {
                            instructionLabel.setVisible(true);
                            instructionLabel.setText("Obrázek nelze přečíst!: " + e.toString());
                        }
                        if (image == null) {        //nastává při špatném (neobrázkovém) formátu
                            instructionLabel.setVisible(true);
                            instructionLabel.setText("Nelze přečíst!: neznámý formát obrázku.");
                        } else {

                            //Pole se vzory
                            File[] upperCaseExamples = new File(new File("").getAbsolutePath() + "\\src\\upperCase").listFiles();       //pole souborů ve složce upperCase
                            File[] lowerCaseExamples = new File(new File("").getAbsolutePath() + "\\src\\lowerCase").listFiles();       //pole souborů ve složce lowerCase
                            File[] usersUpperCaseExamples = new File(new File("").getAbsolutePath() + "\\src\\usersUpperCase").listFiles();       //pole souborů ve složce upperCase
                            File[] usersLowerCaseExamples = new File(new File("").getAbsolutePath() + "\\src\\usersLowerCase").listFiles();       //pole souborů ve složce lowerCase

                            //Sjednocení polí
                            File[] examples = new File[upperCaseExamples.length
                                    + lowerCaseExamples.length
                                    + usersUpperCaseExamples.length
                                    + usersLowerCaseExamples.length];
                            int fileIndex = 0;
                            for (File[] dir : new File[][]{upperCaseExamples, lowerCaseExamples, usersUpperCaseExamples, usersLowerCaseExamples}) {
                                for (File f : dir) {
                                    examples[fileIndex] = f;
                                    fileIndex++;
                                }
                            }

                            int imageWidth = image.getWidth();
                            int imageHeight = image.getHeight();

                            int minDifference = imageWidth * imageHeight * 255;      //nejnižší spočtená hodnota rozdílnosti nějakého vzoru
                            String theMostSimilarLetter = "#";       //nejpodobnější písmeno

                            //Vyhodnocení podobnosti každého ze vzorů
                            for (File exampleF : examples) {
                                BufferedImage example = null;
                                try {
                                    example = ImageIO.read(exampleF);
                                } catch (IOException e) {
                                    System.out.println(e.toString());
                                }
                                if (example != null) {
                                    //každá ze složek RGB se vyhodnocuje zvlášť --> citlivost na barvy
                                    int exampleWidth = example.getWidth();
                                    int exampleHeight = example.getHeight();

                                    //výpočty pro 3 hodnoty rozdílnosti - pro každou složku RGB
                                    int[] differences = {0, 0, 0};
                                    for (int x = 0; x < imageWidth; x++) {
                                        for (int y = 0; y < imageHeight; y++) {

                                            //v případě rozdílných rozměrů vzoru a zkoumaného obrázku se některé pixely vynechávají (považováno za zanedbatelnou ztrátu přesnosti)
                                            int exampleXCoordinate = (int) (x * (float) exampleWidth / imageWidth);
                                            int exampleYCoordinate = (int) (y * (float) exampleHeight / imageHeight);
                                            differences[0] += Math.abs(new Color(image.getRGB(x, y)).getRed() - new Color(example.getRGB(exampleXCoordinate, exampleYCoordinate)).getRed());
                                            differences[1] += Math.abs(new Color(image.getRGB(x, y)).getGreen() - new Color(example.getRGB(exampleXCoordinate, exampleYCoordinate)).getGreen());
                                            differences[2] += Math.abs(new Color(image.getRGB(x, y)).getBlue() - new Color(example.getRGB(exampleXCoordinate, exampleYCoordinate)).getBlue());
                                        }
                                    }
                                    //zapamatování písmene, pokud je vzor nejpodobnější
                                    System.out.println("doc");
                                    for (int difference : differences) {
                                        System.out.println("nac");
                                        if (difference < minDifference) {
                                            System.out.println("nac");
                                            minDifference = difference;
                                            theMostSimilarLetter = Character.toString(exampleF.getName().charAt(0));        //první písmeno názvu vzoru musí být skutečným písmenem na obrázku vzoru
                                        }
                                    }
                                }
                            }
                            //Vypíše výsledek
                            recognizedLetter.setText(theMostSimilarLetter);

                            //Odemnkne možnosti uložení
                            instructionLabel.setVisible(true);
                            colonLabel.setVisible(true);
                            recognizedLetter.setVisible(true);
                            jRadioButton1.setVisible(true);
                            jRadioButton2.setVisible(true);
                            correctingTextField.setVisible(true);
                            saveButton.setVisible(true);
                            jRadioButton1.setEnabled(true);
                            jRadioButton2.setEnabled(true);
                        }
                    }
                }

                return super.importData(comp, t);       //Generuje NB
            }
        }
        );     //Konec reakce na přetažení obrázku

        //Reakce na volbu 1 - správné rozpoznání
        jRadioButton1.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e
            ) {
                correctingTextField.setEnabled(false);
                saveButton.setEnabled(true);
            }
        }
        );

        //Reakce na volbu 2 - chybné rozpoznání
        jRadioButton2.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e
            ) {
                correctingTextField.setEnabled(true);
                correctingTextField.setEditable(true);
                if (correctingTextField.getText().length() == 1
                        && "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(correctingTextField.getText().charAt(0)) > -1) {      // vrácená -1 by indikovala nepřítomnost znaku ve vlákně
                    saveButton.setEnabled(true);
                } else {
                    saveButton.setEnabled(false);
                }
            }
        }
        );

        //Reakce na text field v případě volby chybného rozpoznání
        correctingTextField.addActionListener(
                new ActionListener() {
            //co když napíšu 1 písmeno, odentruji, připíšu víc písmen a bez odentrování kliknu na "Save"?
            @Override
            public void actionPerformed(ActionEvent e
            ) {
                if (correctingTextField.getText().length() == 1
                        && "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(correctingTextField.getText().charAt(0)) > -1) {      // vrácená -1 by indikovala nepřítomnost znaku ve vlákně
                    saveButton.setEnabled(true);
                } else {
                    saveButton.setEnabled(false);
                }
            }
        }
        );

        //Reakce na tlačítko "Save"
        saveButton.addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e
            ) {
                if (jRadioButton1.isSelected() || (correctingTextField.getText().length() == 1
                        && "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(correctingTextField.getText().charAt(0)) > -1)) {      // vrácená -1 by indikovala nepřítomnost znaku ve vlákně

                    //Uložení obrázku do složky examples pod názvem ve formátu: znak, pomlčka a volné pořadové číslo (např. "a-123")
                    String exampleName = "";     //název souboru
                    //Klíčové písmeno názvu soboru
                    if (jRadioButton1.isSelected()) {
                        exampleName = recognizedLetter.getText();
                    } else if (jRadioButton2.isSelected()) {
                        exampleName = String.valueOf(correctingTextField.getText().charAt(0));
                    }
                    
                    String projectPath = new File("").getAbsolutePath();        //načítá cestu složky projektu
                    String examplesPath;
                    if (exampleName.toLowerCase().equals(exampleName)) {
                        examplesPath = "\\src\\usersLowerCase";
                    } else {
                        examplesPath = "\\src\\usersUpperCase";
                    }
                    File[] examples = new File(projectPath + examplesPath).listFiles();        //doplňuje cestu podsložkami src a examples
                    
                    //Hledání volného pořadového čísla
                    boolean isTaken = true;
                    for (int i = 0; isTaken; i++) {
                        isTaken = false;
                        
                        for (File f : examples) {
                            //kontrola, zda se tak už nějaký soubor nejmenuje
                            if (f.getName().substring(0, f.getName().length() - 4).equals(exampleName + "-" + String.valueOf(i))) {        //jména příkladů jsou ve tvaru "a-123"
                                isTaken = true;
                            }
                        }

                        if (!isTaken) {
                            exampleName = exampleName.concat("-" + String.valueOf(i)); //Uložení importované image pod názvem exampleName
                            try {
                                ImageIO.write(image, "png", new File(new File("").getAbsolutePath() + "\\src\\usersExamples\\" + exampleName + ".png"));
                            } catch (IOException ex) {
                                Logger.getLogger(OCR_W.class.getName()).log(Level.SEVERE, null, ex);        //gen. NB
                            }
                            break;
                        }
                    }
                } else {        //nezvolen jRadioButton1 (správné rozpoznání) a v correctingTextfieldu není právě jedno písmeno
                    saveButton.setEnabled(false);
                }
            }
        }
        );
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    //@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        pictureLabel = new javax.swing.JLabel();
        recognizedLetter = new javax.swing.JTextField();
        colonLabel = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        correctingTextField = new javax.swing.JTextField();
        saveButton = new javax.swing.JButton();
        instructionLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pictureLabel.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        pictureLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pictureLabel.setText("Drag and drop a picture here");
        pictureLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        recognizedLetter.setEditable(false);
        recognizedLetter.setBackground(new java.awt.Color(255, 255, 255));
        recognizedLetter.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        recognizedLetter.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        recognizedLetter.setBorder(null);
        recognizedLetter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recognizedLetterActionPerformed(evt);
            }
        });

        colonLabel.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        colonLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        colonLabel.setLabelFor(recognizedLetter);
        colonLabel.setText("Recognized letter:");

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setText("Save as this letter");
        jRadioButton1.setEnabled(false);

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("It is another letter:");
        jRadioButton2.setEnabled(false);

        correctingTextField.setEditable(false);
        correctingTextField.setEnabled(false);

        saveButton.setText("Save");
        saveButton.setEnabled(false);

        instructionLabel.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        instructionLabel.setForeground(new java.awt.Color(102, 102, 102));
        instructionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        instructionLabel.setText("Text");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(instructionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pictureLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addComponent(colonLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(recognizedLetter, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRadioButton1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jRadioButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(correctingTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(pictureLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 284, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(instructionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(colonLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(recognizedLetter, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jRadioButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButton2)
                            .addComponent(correctingTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(saveButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void recognizedLetterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recognizedLetterActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_recognizedLetterActionPerformed

    /**
     * Spustí aplikační okno.
     *
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Sets the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OCR_W.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OCR_W.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OCR_W.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OCR_W.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Creates and displays the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new OCR_W().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel colonLabel;
    private javax.swing.JTextField correctingTextField;
    private javax.swing.JLabel instructionLabel;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JLabel pictureLabel;
    private javax.swing.JTextField recognizedLetter;
    private javax.swing.JButton saveButton;
    // End of variables declaration//GEN-END:variables
}
